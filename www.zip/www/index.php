<?php 
	$titulopagina = "Inicio del Sistema";

	require_once 'includes/header.php';
	
	# menu
	require_once 'menu.php';

	# banner
	require_once 'banner.php';

	require_once 'includes/footer.php';
