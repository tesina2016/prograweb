<!DOCTYPE html>
<html>
<head>
	<title>Creacion del Banner</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style type="text/css">
		#banner {
			width: 100%;
			height: 200px;
			background-image: url('/img/banner.jpg');
			background-position: center;
			background-size: cover;
			background-repeat: no-repeat;

		}
		#logo {
			float: left;
		}
		#texto{
			float: right;
			color: white;
			font-size: 30px;
			margin-top: 120px;
			margin-right: 30px;
		}
		.limpiar {
			clear: both;
		}
	</style>
</head>
<body>
	<header id="banner">
		<div id="logo">
			<img id="imagen" src="img/logo.png">
		</div>
		<div id="texto">
			Programacion Web
		</div>
		<div class="limpiar"></div>
	</header>
	<?php include "clase09a.php"; ?>
	<?php include "clase09b.php"; ?>
</body>
</html>