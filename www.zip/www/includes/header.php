<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="author" content="Delio Coss Camilo">
	<title>
		<?php echo $titulopagina; ?>
	</title>
	<link rel="stylesheet" type="text/css" 
	href="../bt4/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" 
	href="../css/dccsoft.css">
</head>
<body>
