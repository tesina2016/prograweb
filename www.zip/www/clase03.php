<!DOCTYPE html>
<html>
<head>
	<title>Manejo de Texto en HTML5</title>
	<meta charset="utf-8">
	<meta name="author" content="Delio Coss Camilo">
	<meta name="description" content="Manejo de Texto en HTML5">
	<meta name="keywords" content="p, h1, h2,h3,h4,h5,h6 em, i,b">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	<h1>Conmenzando con manejo de texto</h1>
	<p>
		El lenguaje de marcado es un lenguaje que nos obliga a marcar todo elemento o bien llamado objeto dentro de mi documento web.
	</p>
	<h2>Uso de elemntos dentro del texto</h2>
	<p>
		<strong>Esto esta en negritas (strong) </strong><br>
		<b>Esto también ( b )</b>
	</p><hr>

	<h2>Uso de elemntos dentro del texto</h2>
	<p>
		<em>Esto esta enfatizado con (em) </em><br>
		<i>Esto también ( i )</i>
	</p><hr>

	<h3>Manejo de Subrayado y tachado</h3>
	<p>
		<u>Esto esta subrayado</u>, <del>Pero esto esta tachado</del><br>
	</p>
	<hr><br><br>
	<h4>Formulas</h4>
	<p>
		h<sub>2</sub>o<br>
		y= x<sup>2</sup>
	</p>
	<h7>Que pasara?</h7>h
	<h1>Texto 1</h1>
	<h2>Texto 2</h2>
	<h3>Texto 3</h3>
	<h4>Texto 4</h4>
	<h5>Texto 5</h5>
	<h6>Texto 6</h6>
	<br>
</body>
</html>