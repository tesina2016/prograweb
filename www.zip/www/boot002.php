<!DOCTYPE html>
<html>
<head>
	<title>Comenzando con BT4</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" type="text/css" href="bt4/css/bootstrap.min.css">

</head>
<body>
	<div class="container">
		<!--
		<div class="row">
			<div class="col-4">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
			<div class="col-4">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
			<div class="col-4">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
		</div>
		<hr>

		<div class="row">
			<div class="col">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
			<div class="col">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
			<div class="col">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12 col-md-4 col-lg 6">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
			<div class="col-12 col-md-4 col-lg-6">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
			<div class="col-12 col-md-4 col-lg-12">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga possimus explicabo veniam nobis, est quibusdam quas, expedita pariatur illum rem necessitatibus fugit deleniti dolore, quasi quaerat minima itaque, aut cumque.</p>
			</div>
		</div>
		-->

		<div class="row">
			<div class="col">
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas laudantium assumenda, magnam natus voluptatum eligendi dolorum nobis enim veritatis impedit dignissimos, aut eveniet sunt ex! Fuga facere possimus voluptas repudiandae.
				</p>
			</div>
			<div class="col">
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas laudantium assumenda, magnam natus voluptatum eligendi dolorum nobis enim veritatis impedit dignissimos, aut eveniet sunt ex! Fuga facere possimus voluptas repudiandae.
				</p>
			</div>
		</div>
		
	</div>

	<script type="text/javascript" src="jqry/jquery.min.js"></script>
	<script type="text/javascript" src="bt4/js/bootstrap.min.js"></script>
</body>
</html>