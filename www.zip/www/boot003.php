<!DOCTYPE html>
<html>
<head>
	<title>Comenzando con BT4</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" type="text/css" href="bt4/css/bootstrap.min.css">

</head>
<body>
	<div class="container bg-warning">
		<div class="row">
			<div class="col mt-5">
				<h1 class="bg-danger text-white py-3 text-center">Noticias</h1>
			</div>
		</div>
		<div class="row">
			<div class="col bg-dark text-white m-4">
				<h2 class="mt-5 ml-2">Alumnos</h2>
				<p class="text-justify  p-4">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum architecto neque quae aspernatur at, saepe alias eum voluptatibus minus delectus quibusdam corporis officiis sunt eveniet vero voluptate optio! Placeat, voluptatem.
				</p>
			</div>
			<div class="col bg-info text-white  m-4">
				<h2   class="mt-5 ml-2">Profesores</h2>
				<p class="text-justify p-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis aperiam voluptatem, id, voluptatibus hic aliquid similique qui recusandae, quasi adipisci laborum nisi. Illo velit ipsam cumque id laborum sunt perspiciatis!</p>
			</div>
			<div class="col bg-success text-white m-4">
				<h2  class="mt-5 ml-2">Administrador</h2>
				<p class="text-justify p-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error possimus tenetur architecto quam in rem molestiae eveniet, aspernatur hic laborum! Minus quae, repellendus facilis adipisci saepe recusandae autem est tempore.</p>
			</div>
		</div>
	</div> <!-- Termina Contenedor -->

<script type="text/javascript" src="jqry/jquery.min.js"></script>
<script type="text/javascript" src="bt4/js/bootstrap.min.js"></script>
</body>
</html>