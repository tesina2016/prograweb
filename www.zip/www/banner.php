<section id="banner">	
	<div class="container">
		<div class="row">
			<div class="col jumbotron text-light">
				<h1 class="display-4">
					Bienvenidos a la P. Web
				</h1>
				<p class="lead">
					Con un poquito de fe, ustedes aprenderan lo basico de la programacion web, aplicandola en el desarrollo de un sistema de informacion
				</p>
				<hr class="my-4">
				<p>
					Debemos de aplicar los conocimientos adquiridos durante el Semestre
				</p>
				<a class="btn btn-primary btn-lg" href="#" role="button">
					Leer mas ...
				</a>
			</div>
		</div>
	</div>
</section>
