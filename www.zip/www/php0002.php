<?php 
	$titulopagina = "Uso de variables y comillas";
	require_once 'includes/header.php';

	$nombre = "Delio";
	$apellidos = 'Coss Camilo';
	#------
	$edad = 57;
	$peso = 75.5;
	$inscrito = true;

	# Uso de comillas dobles y evaluacion dentro de la cadena los valores de las variables

	echo "Usted es la persona, $nombre $apellidos cuyo peso es de $peso con una edad de $edad";

	echo "<br/><hr/>";

	echo 'Usted es la persona, $nombre $apellidos cuyo peso es de $peso con una edad de $edad';

	echo "<br/><hr/>";

	# Uso de comillas simples y concatenacion de valores
	echo 'Usted es la persona, '.$nombre.' '.$apellidos.' cuyo peso es de '.$peso.' con una edad de '.$edad;

	require_once 'includes/footer.php';

