<!DOCTYPE html>
<html>
<head>
	<title>Manejo de Imagenes</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style type="text/css">
		body {
			width: 960px;
			margin: 0px auto;
		}
		#bandera {
			width: 100%;
			height: 400px;
			float: left;
		}
		#verde {
			background-color: green;
			float: left;
		}
		#blanca {
			background-color: white;
			float: left;
		}
		#roja {
			background-color: red;
			float: right;
		}
		.caja {
			width: 33%;
			height: 100%;
		}
		#escudo {
			margin-top: 20px;
			width: 90%;
			height: 80%;
		}
		#mensaje {
			text-align: center;
			font-weight: 1000;
			background-color: red;
			color: white;
			padding: 20px 50px;
		}
		.limpiar {
			clear: both;
		}
	</style>
</head>
<body>
	<h1 id="mensaje">Viva Mexico !!!</h1>
	<div id="bandera">
		<div id="verde" class="caja"></div>
		<div id="blanca" class="caja">
			<img id="escudo" src="img/escudo.png">
		</div>
		<div id="roja" class="caja"></div>
	</div>
	<div class="limpiar"></div>
	<h1 id="mensaje">Viva Mexico !!!</h1>
</body>
</html>