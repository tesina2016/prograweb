<?php 
	$titulopagina = "Comenzando con PHP";
	require_once 'includes/header.php';
?>	<!-- Contenido de la pagina web -->
	<div class="container">
		<div class="row">
			<div class="col jumbotron text-light">
				<p>
					Comenzamos a unir piezas para incremetar la productividad con el concepto de reuso de codigo.
						<ul>
							<li>Reducimos tiempo de Mantto</li>
							<li>Control de efectos colaterales</li>
							<li>Centralizar codigo</li>
						</ul>
				</p>
			</div>
		</div>
	</div>
	<!-- Termina contenido pagina web -->
<?php 
	require_once 'includes/footer.php';
?>
