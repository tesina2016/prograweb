<?php 
	require_once '../includes/header.php';

	# Contenido de la pagina.
	require_once 'menu.php';
	require_once 'login.php';
	
	require_once '../includes/footer.php';