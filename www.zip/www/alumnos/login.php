<section id="login">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col col-md-6">
				<form method="get" action="index.php">
					<div class="form-group">
						<label for="nocontrol">No. de Control</label>
						<input type="text" class="form-control" />
					</div>
					<div class="form-group">
						<label for="password">Password</label>
						<input type="password" class="form-control" />
					</div>
					<input type="submit" name="btn_enviar" value="Solicitar Entrada">
				</form>
			</div>
		</div>
	</div>
</section>