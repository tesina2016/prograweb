<!DOCTYPE html>
<html>
<head>
	<title>Implementar Reglas de Presentacion</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	<h2 style="color:white; background-color: black">		Primera Forma (in-line)
	</h2>
	<p style="color: yellow; background-color: blue ">
		Esta forma es para probar una regla de presentacion sin modificar nuestro script en otros lugares
	</p>
</body>
</html>