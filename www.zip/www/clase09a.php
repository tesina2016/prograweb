<style type="text/css">
	#menu {
		margin: 0px;
		width: 100%;
		background-color: black;
		color: white;
		padding: 0px;
		float: left;
	}
	#menu ul {
		float: right;
	}
	#menu ul li {
		width: 150px;
		text-align: center;
		display: inline-block;
		line-height: 40px;
	}
	#menu ul li a {
		color: white;
		text-decoration: none;
	}

	#menu ul li a:hover {
		display: inline-block;
		color: white;
		width: 150px;
		font-size: 30px;
		border-radius: 20px;
		background-color: rgba(255,255,255,0.2);
	}

</style>
<nav id="menu">
	<ul>
		<li><a href="">Inicio</a></li>
		<li><a href="">Servicios</a></li>
		<li><a href="">Contactame</a></li>
		<li><a href="">Acerca de</a></li>
	</ul>
</nav>