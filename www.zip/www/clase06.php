<!DOCTYPE html>
<html>
<head>
	<title>Conociendo el Modelo de Cajas</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/dcc.css">
</head>
<body>
	<h2 id="txtBN" 
	class="margen0 h2margenabajo h2relleno10 borderRojoAbajo">Conociendo el Modelo de cajas</h2>
	<p class="borderNegro01 paddingraro">Es fundamental entender el concepto del modelo de cajas para conocer los elementos que estan involucrados</p>
	<p class="borderNegro01 padding1020">
		Estos elementos son:
		padding, margin y border.
	</p>
</body>
</html>