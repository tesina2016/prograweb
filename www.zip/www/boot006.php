<!DOCTYPE html>
<html>
<head>
	<title>Comenzando con BT4</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" type="text/css" href="bt4/css/bootstrap.min.css">

</head>
<body>

<div class="container">
	<div class="row">
		<div class="container bg-dark text-light text-center py-3">
			&copy Copyright 2019 by dccSoft
		</div>
	</div>
</div>
	

<script type="text/javascript" src="jqry/jquery.min.js"></script>
<script type="text/javascript" src="bt4/js/bootstrap.min.js"></script>
</body>
</html>
