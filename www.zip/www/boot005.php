<!DOCTYPE html>
<html>
<head>
	<title>Comenzando con BT4</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" type="text/css" href="bt4/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/dccsoft.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col jumbotron text-light">
				<h1 class="display-4">
					Bienvenidos a la P. Web
				</h1>
				<p class="lead">
					Con un poquito de fe, ustedes aprenderan lo basico de la programacion web, aplicandola en el desarrollo de un sistema de informacion
				</p>
				<hr class="my-4">
				<p>
					Debemos de aplicar los conocimientos adquiridos durante el Semestre
				</p>
				<a class="btn btn-primary btn-lg" href="#" role="button">
					Leer mas ...
				</a>
			</div>
		</div>
	</div>

	

<script type="text/javascript" src="jqry/jquery.min.js"></script>
<script type="text/javascript" src="bt4/js/bootstrap.min.js"></script>
</body>
</html>