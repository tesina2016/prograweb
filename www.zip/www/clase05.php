<!DOCTYPE html>
<html>
<head>
	<title>Uso de Id y Class</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/dcc.css">
</head>
<body>
	<h2 id="txtBN">Usando id</h2>
	<p id="txtAA" class="txt14px">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti, nesciunt cum animi eveniet perferendis unde non a iusto vel optio eaque hic voluptatem maxime eos repellat adipisci consectetur? Soluta, excepturi!
	</p>
	<p class="txt14px">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus omnis nemo perspiciatis pariatur vero et nobis quaerat tempora labore cumque, laborum consequuntur dolorem sequi, quibusdam error atque, sunt corporis nesciunt.
	</p>
	<h4>
		Mensaje de Advertencia
	</h4>
	<p class="txtAdvertencia">
		Deben de apurarse para aprobar la materia
	</p>
</body>
</html>