<!DOCTYPE html>
<html>
<head>
	<title>Comenzando con BT4</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" type="text/css" href="bt4/css/bootstrap.min.css">

</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col">

				<ul class="list-group">
  					<li class="list-group-item">Cras justo odio</li>
  					<li class="list-group-item">Dapibus ac facilisis in</li>
  					<li class="list-group-item">Morbi leo risus</li>
  					<li class="list-group-item">Porta ac consectetur ac</li>
  					<li class="list-group-item">Vestibulum at eros</li>
				</ul>
			</div>
		</div>
	</div>

	

<script type="text/javascript" src="jqry/jquery.min.js"></script>
<script type="text/javascript" src="bt4/js/bootstrap.min.js"></script>
</body>
</html>