<!DOCTYPE html>
<html>
<head>
	<title>Implementar Reglas de Presentacion</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style type="text/css">
		h2 {
			color: white;
			background-color: black;
		}
		p {
			color: yellow;
			background-color: blue;
		}
	</style>
</head>
<body>
	<h2>
			Segunda Forma (in-line, area de Configuración)
	</h2>
	<p>
		Esta forma es para probar una regla de presentacion sin modificar nuestro script en otros lugares
	</p>
</body>
</html>