<style type="text/css">
	#contenedor {
		background-color: rgba(0,0,0,0.15);
		width: 100%;
		min-height: 400px;
		border: 1px solid black;
	}
	#main {
		float: left;
		width: 50%;
	}
	#noticias {
		float: right;
		width: 30%;
	}
	#footer {
		clear: both;
	}
	.padding1020 {
		padding: 10px 20px;		
	}
	.texto {
		line-height: 40px;
		background-color: black;
		color: white;
		font-size: 25px;
		text-align: center;
	}
	.texto20 {
		font-size: 20px;
		font-weight: 500px;
	}
</style>
<section id="contenedor">
	<section id="main" class="padding1020">
		<h1 class="texto">Bienvenido al Curso</h1>
		<p class="texto20">
			En este curso aprenderá las bases de la programación web obteniendo los conocimientos basicos y esenciales para crear un sitio web dinamico utilizando Php y Mysql			
		</p>
	</section>
	<section id="noticias" class="padding1020">
		<h1 class="texto">Noticias</h1>
		<ul class="texto20">
			<li>
				El tiburon no perderá esta semana
			</li>
			<li>
				Donald Trump quiere comprar Mexico y Groelandia
			</li>
			<li>
				La 4T se ha convertido en el Mito
			</li>
		</ul>
	</section>
	<section id="footer"  class="padding1020">
		<h1 class="texto">dccSoft 2019</h1>
	</section>
</section>