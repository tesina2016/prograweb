<!DOCTYPE html>
<html>
<head>
	<title>Tipos de Elementos</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style type="text/css">
		body {
			margin: 0px auto;
			width: 960px;
		}
		#left {
			border: 1px solid black;
			float: left;
			background-color: darkgreen;
		}
		#right {
			border: 1px solid black;
			float: right;
			background-color: darkred;
		}
		.enlinea {
			display: inline;
		}
		.width220 {
			width: 320px;
		}
		.width420 {
			width: 420px;
		}
	</style>
</head>
<body>
	<div id="left" class="width420">
		<h2 class="enlinea">Tipos Elementos 01</h2>
		<p class="enlinea">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad libero accusantium recusandae cumque saepe cum tempore nobis molestiae in, eligendi pariatur porro facilis asperiores. Labore, accusantium quidem nobis voluptatum doloribus.
		</p>
		<p class="enlinea">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis harum, porro repellat perferendis. Consectetur minima saepe, quaerat quis? Delectus commodi perspiciatis ullam officia labore excepturi illum praesentium itaque iusto, reprehenderit.
		</p>		
	</div>
	<div id="right" class="width420">
		<h2 class="enlinea width220">Tipos Elementos 02</h2>
		<p class="enlinea">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad libero accusantium recusandae cumque saepe cum tempore nobis molestiae in, eligendi pariatur porro facilis asperiores. Labore, accusantium quidem nobis voluptatum doloribus.
		</p>
		<p class="enlinea">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis harum, porro repellat perferendis. Consectetur minima saepe, quaerat quis? Delectus commodi perspiciatis ullam officia labore excepturi illum praesentium itaque iusto, reprehenderit.
		</p>		
	</div>
</body>
</html>